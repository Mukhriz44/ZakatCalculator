package com.example.zakatcalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;
import android.widget.TextView;
import android.text.SpannableString;
import android.text.style.ClickableSpan;
import android.view.View;
import android.net.Uri;
import android.content.Intent;
import android.text.Spannable;


public class AboutActivity extends AppCompatActivity {

    Toolbar aboutToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        aboutToolbar = findViewById(R.id.about_toolbar);
        setSupportActionBar(aboutToolbar);
        getSupportActionBar().setTitle("About");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        TextView appWebsiteTextView = findViewById(R.id.textViewAppWebsite);

        SpannableString spannableString = new SpannableString(appWebsiteTextView.getText());
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                String githubUrl = "https://github.com/Mukhriz44/";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(githubUrl));
                startActivity(intent);
            }
        };
        spannableString.setSpan(clickableSpan, 0, spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        appWebsiteTextView.setText(spannableString);
        appWebsiteTextView.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
        appWebsiteTextView.setLinkTextColor(getResources().getColor(R.color.blue)); // Set link text color to white

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
