package com.example.zakatcalculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    RadioGroup radioGroup;
    RadioButton radioButton;
    Button calcZakat, resetButton; // Added resetButton
    TextView tvTotVal, tvGoldPay, tvTotZakat;
    EditText etWeight, etGoldVal;
    Toolbar myToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle(R.string.app_name);

        etWeight = findViewById(R.id.etWeight);
        etGoldVal = findViewById(R.id.etGoldValue);

        radioGroup = findViewById(R.id.radioGroup);
        calcZakat = findViewById(R.id.btCalc);
        calcZakat.setOnClickListener(this);

        resetButton = findViewById(R.id.resetButton); // Initialize the resetButton
        resetButton.setOnClickListener(this); // Set click listener for the resetButton

        tvTotVal = findViewById(R.id.tvTotVal);
        tvGoldPay = findViewById(R.id.tvGoldPay);
        tvTotZakat = findViewById(R.id.tvTotZakat);
    }

    // Rest of your code...

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.item_share) {
            // Update MIME type to "text/plain" instead of "text.plain"
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, "Please use my application - http://t.co/app");

            // Ensure there is an activity to handle the intent before starting it
            if (shareIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(Intent.createChooser(shareIntent, null));
            } else {
                // Handle the case where no app can handle the share intent
                Toast.makeText(this, "No app can handle this action", Toast.LENGTH_SHORT).show();
            }

            return true;
        } else if (item.getItemId() == R.id.item_about) {
            Intent aboutIntent = new Intent(this, AboutActivity.class);
            startActivity(aboutIntent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btCalc) {
            // Code for the Calculate button
            int radioId = radioGroup.getCheckedRadioButtonId();
            radioButton = findViewById(radioId);
            String choice = (String) radioButton.getText();

            try {
                double weight = Double.parseDouble(etWeight.getText().toString());
                double goldVal = Double.parseDouble(etGoldVal.getText().toString());
                double totValGold = 0, zPay = 0, totZ = 0;
                if (choice.equalsIgnoreCase("keep")) {
                    totValGold = weight * goldVal;
                    zPay = (weight - 85) * goldVal;
                    if (zPay <= 0) {
                        zPay = 0;
                    }
                    totZ = zPay * 0.025;
                } else if (choice.equalsIgnoreCase("wear")) {
                    totValGold = weight * goldVal;
                    zPay = (weight - 200) * goldVal;
                    if (zPay <= 0) {
                        zPay = 0;
                    }
                    totZ = zPay * 0.025;
                }

                // Format the double values with two decimal points
                String formattedTotValGold = String.format("Total value of the gold: RM %.2f", totValGold);
                String formattedZPay = String.format("Total Gold Value Zakat Payable: RM %.2f", zPay);
                String formattedTotZ = String.format("Total Zakat: RM %.2f", totZ);

                tvTotVal.setText(formattedTotValGold);
                tvGoldPay.setText(formattedZPay);
                tvTotZakat.setText(formattedTotZ);
            } catch (NumberFormatException e) {
                Toast.makeText(MainActivity.this, "Fill the number properly", Toast.LENGTH_SHORT).show();
            }
        } else if (v.getId() == R.id.resetButton) {
            // Code for the Reset button
            resetForm();
        }
    }


    // Method to reset the form
    private void resetForm() {
        etWeight.getText().clear();
        etGoldVal.getText().clear();
        radioGroup.clearCheck();
        tvTotVal.setText("Total value of the gold: ");
        tvGoldPay.setText("Total Gold Value Zakat Payable: ");
        tvTotZakat.setText("Total Zakat: ");
    }
}